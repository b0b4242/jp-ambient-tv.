package com.jpambient.app

import android.app.Activity
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

class MainActivity : Activity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var titleOverlay: TextView
    private var currentIndex = 0

    // First scene is a public-domain National Park Service landscape video.
    // Add more direct MP4 links here to expand the rotation.
    private val scenes = listOf(
        Scene(
            "ACADIA · MOUNTAINS & LAKES",
            "https://npgallery.nps.gov/GetAsset/a84245c3-7109-46a0-bf28-0165a464c515/proxyhires"
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        )

        val root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }
        playerView = PlayerView(this).apply {
            useController = false
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
            layoutParams = FrameLayout.LayoutParams(-1, -1)
        }
        titleOverlay = TextView(this).apply {
            text = "JP AMBIENT  ·  LOADING LANDSCAPE…"
            textSize = 13f
            letterSpacing = 0.16f
            setTextColor(0xFFE9F1FF.toInt())
            setPadding(40, 30, 40, 30)
            setShadowLayer(12f, 0f, 2f, 0xCC000000.toInt())
            layoutParams = FrameLayout.LayoutParams(-1, -2, android.view.Gravity.TOP)
        }
        root.addView(playerView)
        root.addView(titleOverlay)
        setContentView(root)
        startPlayer()
    }

    private fun startPlayer() {
        val exo = ExoPlayer.Builder(this).build()
        player = exo
        playerView.player = exo
        val items = scenes.map { MediaItem.fromUri(it.url) }
        exo.setMediaItems(items)
        exo.repeatMode = Player.REPEAT_MODE_ALL
        exo.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                currentIndex = (player?.currentMediaItemIndex ?: 0).coerceAtLeast(0)
                titleOverlay.text = "JP AMBIENT  ·  ${scenes[currentIndex].title}"
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_BUFFERING) {
                    titleOverlay.text = "JP AMBIENT  ·  LOADING LANDSCAPE…"
                }
                if (playbackState == Player.STATE_READY) {
                    titleOverlay.text = "JP AMBIENT  ·  ${scenes[currentIndex].title}"
                }
            }
        })
        exo.prepare()
        exo.playWhenReady = true
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val exo = player
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                if (exo?.isPlaying == true) exo.pause() else exo?.play()
                return true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_MEDIA_NEXT -> {
                if ((exo?.mediaItemCount ?: 0) > 1) exo?.seekToNextMediaItem()
                return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                if ((exo?.mediaItemCount ?: 0) > 1) exo?.seekToPreviousMediaItem()
                return true
            }
            KeyEvent.KEYCODE_BACK -> {
                finish()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        playerView.player = null
        player?.release()
        player = null
        super.onDestroy()
    }

    private data class Scene(val title: String, val url: String)
}
