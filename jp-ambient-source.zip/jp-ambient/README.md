# JP Ambient (prototype)

A simple Android/Fire TV ambient video player. It launches fullscreen, plays a scenic MP4, loops it, and hides Android navigation bars. This is an early prototype, not yet a real system-level screensaver: Fire OS may not allow a sideloaded app to automatically replace the built-in screensaver.

## Build without a computer
1. Create a GitHub repository named `jp-ambient`.
2. Upload all files from this folder, keeping the same folder structure.
3. Open the repository's **Actions** tab.
4. Choose **Build JP Ambient APK** and tap **Run workflow** (or wait for the push build).
5. Open the completed workflow run, scroll to **Artifacts**, and download `JP-Ambient-debug-apk`.
6. Extract the ZIP and install `app-debug.apk` on the Fire TV using your usual sideload method.

## Controls
- OK/Enter: pause or resume.
- Back: exit.
- Left/Right: next/previous scene (once more scene URLs are added).

## Add more scenes
In `app/src/main/java/com/jpambient/app/MainActivity.kt`, add more `Scene("TITLE", "DIRECT_MP4_URL")` entries to `scenes`. Use direct MP4 links that permit streaming; ordinary webpage URLs won't work.

## Notes
- The current sample is a 35-second scenic video from the U.S. National Park Service marked public domain on its asset page.
- Video playback requires an internet connection.
- This project is provided as source code; it has not been compiled or tested on a physical Fire TV in this environment.
